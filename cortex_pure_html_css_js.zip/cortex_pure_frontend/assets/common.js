(() => {
  const config = window.CORTEX_CONFIG || {};
  const base = String(config.API_BASE || window.location.origin).replace(/\/+$/, "");
  const wsPath = config.WS_PATH || "/ws/data-stream";
  const apiUrl = (path) => `${base}${path.startsWith("/") ? path : `/${path}`}`;
  const wsUrl = () => {
    const url = new URL(base);
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    url.pathname = `${url.pathname.replace(/\/+$/, "")}${wsPath.startsWith("/") ? wsPath : `/${wsPath}`}`;
    url.search = "";
    url.hash = "";
    return url.toString();
  };
  const formatKey = (key) => String(key).replaceAll("_", " ").replace(/\b\w/g, c => c.toUpperCase());
  const thresholds = {
    vib_de: { label: "Drive-end vibration", unit: "mm/s", warn: 4.5, direction: "high" },
    bearing_temp: { label: "Bearing temperature", unit: "°C", warn: 85, direction: "high" },
    motor_current: { label: "Motor current", unit: "A", warn: 75, direction: "high" },
    motor_winding_temp: { label: "Motor winding temperature", unit: "°C", warn: 85, direction: "high" },
    discharge_pressure: { label: "Discharge pressure", unit: "bar", warn: 10, direction: "high" },
    flow: { label: "Flow", unit: "m³/h", warn: 140, direction: "low" },
    suction_pressure: { label: "Suction pressure", unit: "bar", warn: 2, direction: "low" },
    vib_nde: { label: "Non-drive-end vibration", unit: "mm/s", warn: 4.5, direction: "high" },
    pump_speed: { label: "Pump speed", unit: "rpm", warn: 2800, direction: "low" },
    seal_pot_level: { label: "Seal pot level", unit: "%", warn: 30, direction: "low" },
    lube_oil_temp: { label: "Lube oil temperature", unit: "°C", warn: 65, direction: "high" },
    seal_pressure: { label: "Seal pressure", unit: "bar", warn: 2.5, direction: "low" }
  };
  const isWarning = (key, value) => {
    const rule = thresholds[key];
    const n = Number(value);
    return !!rule && Number.isFinite(n) && (rule.direction === "high" ? n > rule.warn : n < rule.warn);
  };
  const setConnection = (connected, label) => {
    const dot = document.getElementById("connection-dot");
    const sideDot = document.getElementById("sidebar-dot");
    const connLabel = document.getElementById("connection-label");
    const sideLabel = document.getElementById("sidebar-status");
    [dot, sideDot].forEach(el => {
      if (el) el.classList.toggle("online", connected);
      if (el) el.classList.toggle("offline", !connected);
    });
    if (connLabel) connLabel.textContent = label || (connected ? "Connected" : "Disconnected");
    if (sideLabel) sideLabel.textContent = label || (connected ? "Connected" : "Disconnected");
  };
  const request = async (path, options = {}) => {
    const response = await fetch(apiUrl(path), {
      ...options,
      headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) }
    });
    const text = await response.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = { detail: text }; }
    if (!response.ok) throw new Error(data.detail || data.message || `HTTP ${response.status}`);
    return data;
  };
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  window.Cortex = { apiUrl, wsUrl, thresholds, isWarning, setConnection, request, formatKey, esc };
})();
