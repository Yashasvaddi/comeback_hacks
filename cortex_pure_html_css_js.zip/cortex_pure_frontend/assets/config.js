// Change this value if your public API is hosted at a different origin.
window.CORTEX_CONFIG = {
  API_BASE: "https://godfatherspersonalcomputer.shop",
  WS_PATH: "/ws/data-stream"
};
