(() => {
  const C = window.Cortex;
  const $ = id => document.getElementById(id);
  let socket = null;
  let lastWarnings = {};
  let eventCount = 0;
  const events = [];
  const knownMeta = new Set(["timestamp", "time", "datetime", "dataset", "dataset_name", "row", "position", "type", "event"]);
  function addEvent(title, detail, kind = "info") {
    events.unshift({ title, detail, kind, time: new Date().toLocaleTimeString() });
    if (events.length > 30) events.pop();
    renderEvents();
  }
  function renderEvents() {
    $("event-list").innerHTML = events.length ? events.map(e => `<div class="event-row"><span class="event-symbol ${e.kind}">${e.kind === "warning" ? "!" : e.kind === "success" ? "✓" : "i"}</span><div class="event-copy"><strong>${C.esc(e.title)}</strong><small>${C.esc(e.detail)}</small></div><time>${C.esc(e.time)}</time></div>`).join("") : '<div class="empty-state compact">No events yet.</div>';
  }
  function sensorEntries(record) {
    return Object.entries(record || {}).filter(([k, v]) => !knownMeta.has(k.toLowerCase()) && v !== null && v !== "" && Number.isFinite(Number(v)));
  }
  function drawSensors(record) {
    const entries = sensorEntries(record);
    let warnings = 0;
    const currentWarnings = {};
    $("sensor-grid").innerHTML = entries.length ? entries.map(([key, raw]) => {
      const rule = C.thresholds[key] || { label: C.formatKey(key), unit: "", warn: null, direction: "high" };
      const value = Number(raw);
      const warning = C.isWarning(key, value);
      if (warning) { warnings++; currentWarnings[key] = true; }
      const previous = lastWarnings[key] === true;
      if (warning && !previous) addEvent("Warning threshold crossed", `${rule.label}: ${value} ${rule.unit}`.trim(), "warning");
      if (!warning && previous) addEvent("Sensor back to normal", `${rule.label}: ${value} ${rule.unit}`.trim(), "success");
      const range = rule.warn ? Math.max(1, Math.min(100, value / (rule.warn * 1.25) * 100)) : 0;
      const fill = rule.direction === "low" && rule.warn ? Math.max(0, Math.min(100, value / (rule.warn * 1.6) * 100)) : range;
      return `<article class="sensor-card ${warning ? "warning" : "normal"}">
        <div class="sensor-top"><span class="sensor-icon">${iconFor(key)}</span><span class="sensor-status ${warning ? "alert" : "ok"}">${warning ? "WARNING" : "NORMAL"}</span></div>
        <div class="sensor-name">${C.esc(rule.label)}</div>
        <div class="sensor-value">${C.esc(value.toLocaleString(undefined, { maximumFractionDigits: 2 }))}<span>${C.esc(rule.unit)}</span></div>
        <div class="meter"><span style="width:${fill}%"></span></div>
        <div class="sensor-foot"><span>${rule.warn ? `${rule.direction === "high" ? "Warning above" : "Warning below"} ${rule.warn} ${rule.unit}` : C.esc(key)}</span><span class="sensor-key">${C.esc(key)}</span></div>
      </article>`;
    }).join("") : '<div class="empty-state">Record received, but no numeric sensor fields were found.</div>';
    lastWarnings = currentWarnings;
    $("warning-count").textContent = warnings;
  }
  function iconFor(key) {
    if (key.includes("temp")) return "♨";
    if (key.includes("vib")) return "〰";
    if (key.includes("pressure")) return "◉";
    if (key.includes("flow")) return "↗";
    if (key.includes("current")) return "ϟ";
    if (key.includes("speed")) return "⟳";
    if (key.includes("level")) return "▥";
    return "⌁";
  }
  function handleMessage(msg) {
    if (msg.type === "data" || msg.type === "record" || msg.type === "sensor_data") {
      const record = msg.data || msg.record || msg.payload || msg;
      const dataset = msg.dataset || record.dataset || record.dataset_name || "Active dataset";
      const row = msg.row ?? msg.position ?? record.row ?? record.position ?? "—";
      const timestamp = msg.timestamp || record.timestamp || record.time || record.datetime || "Timestamp unavailable";
      $("dataset-name").textContent = dataset;
      $("dataset-description").textContent = "Streaming synthetic sensor records";
      $("row-number").innerHTML = `${C.esc(row)} <span class="muted">/ 60</span>`;
      $("record-time").textContent = timestamp;
      $("stream-state").textContent = "Streaming";
      $("stream-note").textContent = "Receiving records from WebSocket";
      drawSensors(record);
    } else if (msg.type === "stream_started") {
      $("stream-state").textContent = "Streaming";
      addEvent("Stream started", msg.dataset || "Backend stream started", "success");
    } else if (msg.type === "dataset_switched") {
      $("dataset-name").textContent = msg.dataset || "Dataset switched";
      $("row-number").innerHTML = `0 <span class="muted">/ 60</span>`;
      $("stream-state").textContent = "Switching";
      lastWarnings = {};
      addEvent("Dataset switched", msg.dataset || "The active dataset changed", "info");
    } else if (msg.type === "end_of_dataset") {
      $("stream-state").textContent = "Completed";
      $("stream-note").textContent = "End of dataset reached";
      addEvent("End of dataset", msg.dataset || "No more rows available", "info");
    } else if (msg.type === "error") {
      addEvent("Stream error", msg.message || msg.detail || "Unknown WebSocket error", "warning");
    } else {
      addEvent("Stream event", msg.type || JSON.stringify(msg), "info");
    }
  }
  function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
    try {
      socket = new WebSocket(C.wsUrl());
      C.setConnection(false, "Connecting");
      $("stream-state").textContent = "Connecting";
      socket.onopen = () => {
        C.setConnection(true, "Connected");
        $("stream-state").textContent = "Connected";
        $("stream-note").textContent = "WebSocket connection is open";
        addEvent("Connected to stream", C.wsUrl(), "success");
      };
      socket.onmessage = event => {
        try { handleMessage(JSON.parse(event.data)); }
        catch { addEvent("Invalid message", event.data.slice(0, 180), "warning"); }
      };
      socket.onerror = () => addEvent("WebSocket error", "Check the public WebSocket proxy and backend logs.", "warning");
      socket.onclose = () => {
        C.setConnection(false, "Disconnected");
        if ($("stream-state").textContent !== "Completed") $("stream-state").textContent = "Disconnected";
        addEvent("Disconnected", "The WebSocket connection closed.", "info");
      };
    } catch (err) {
      C.setConnection(false, "Connection failed");
      addEvent("Connection failed", err.message, "warning");
    }
  }
  $("reconnect-btn").addEventListener("click", () => {
    if (socket) socket.close();
    socket = null;
    connect();
  });
  $("clear-events").addEventListener("click", () => { events.length = 0; renderEvents(); });
  window.addEventListener("beforeunload", () => { if (socket) socket.close(); });
  connect();
})();
