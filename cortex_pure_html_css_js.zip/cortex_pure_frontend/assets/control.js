(() => {
  const C = window.Cortex;
  const $ = id => document.getElementById(id);
  let socket = null;
  let selectedDataset = "dataset_1";
  const logs = [];
  function log(title, detail, kind = "info") {
    logs.unshift({ title, detail, kind, time: new Date().toLocaleTimeString() });
    if (logs.length > 40) logs.pop();
    $("control-log").innerHTML = logs.length ? logs.map(e => `<div class="event-row"><span class="event-symbol ${e.kind}">${e.kind === "warning" ? "!" : e.kind === "success" ? "✓" : "i"}</span><div class="event-copy"><strong>${C.esc(e.title)}</strong><small>${C.esc(e.detail)}</small></div><time>${C.esc(e.time)}</time></div>`).join("") : '<div class="empty-state compact">No activity yet.</div>';
  }
  function selectDataset(name) {
    selectedDataset = name;
    document.querySelectorAll(".dataset-option").forEach(btn => btn.classList.toggle("selected", btn.dataset.dataset === name));
  }
  document.querySelectorAll(".dataset-option").forEach(btn => btn.addEventListener("click", () => selectDataset(btn.dataset.dataset)));
  function setSocketStatus(connected, label) {
    C.setConnection(connected, label);
    $("connection-state-title").textContent = connected ? "Stream connected" : label;
    $("connection-state-copy").textContent = connected ? "This page is receiving WebSocket events." : "This page is not currently receiving stream events.";
    $("connect-btn").disabled = connected;
    $("disconnect-btn").disabled = !connected && !(socket && socket.readyState === WebSocket.CONNECTING);
  }
  function connect() {
    if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) return;
    try {
      socket = new WebSocket(C.wsUrl());
      setSocketStatus(false, "Connecting");
      log("Connecting to WebSocket", C.wsUrl());
      socket.onopen = () => { setSocketStatus(true, "Connected"); log("Connected", "WebSocket is open.", "success"); refreshStatus(); };
      socket.onmessage = event => {
        try {
          const msg = JSON.parse(event.data);
          log(`WebSocket: ${msg.type || "message"}`, msg.dataset ? `Dataset: ${msg.dataset}` : JSON.stringify(msg).slice(0, 180), msg.type === "error" ? "warning" : "info");
          if (msg.dataset) $("current-dataset").textContent = msg.dataset;
          if (msg.row !== undefined || msg.position !== undefined) $("current-position").textContent = msg.row ?? msg.position;
          refreshStatus();
        } catch { log("Message parse error", event.data.slice(0, 180), "warning"); }
      };
      socket.onerror = () => log("WebSocket error", "Check the backend and reverse-proxy WebSocket upgrade configuration.", "warning");
      socket.onclose = () => { setSocketStatus(false, "Disconnected"); log("Disconnected", "This page's WebSocket closed."); };
    } catch (err) { setSocketStatus(false, "Connection failed"); log("Connection failed", err.message, "warning"); }
  }
  function disconnect() {
    if (socket) socket.close();
    socket = null;
    setSocketStatus(false, "Disconnected");
    log("Disconnected this page", "Backend streaming may continue for other clients.");
  }
  async function refreshStatus() {
    try {
      const status = await C.request("/api/data-stream/status");
      const dataset = status.dataset || status.current_dataset || status.active_dataset || "—";
      const position = status.position ?? status.row ?? status.current_row ?? "—";
      const clients = status.connected_clients ?? status.clients ?? status.client_count ?? "—";
      $("current-dataset").textContent = dataset;
      $("current-position").textContent = position;
      $("clients-count").textContent = clients;
      if (status.connected_clients !== undefined || status.clients !== undefined || status.client_count !== undefined) {
        $("connection-state-copy").textContent = `${clients} connected client(s) reported by backend.`;
      }
      return status;
    } catch (err) {
      log("Status request failed", `${err.message}. Confirm API base URL, CORS and route availability.`, "warning");
      return null;
    }
  }
  async function loadDatasets() {
    try {
      const data = await C.request("/api/data-stream/datasets");
      const items = Array.isArray(data) ? data : (data.datasets || data.available_datasets || []);
      if (items.length) {
        const names = items.map(item => typeof item === "string" ? item : item.id || item.name || item.dataset);
        document.querySelectorAll(".dataset-option").forEach(btn => {
          const exists = names.some(name => name === btn.dataset.dataset);
          btn.classList.toggle("unavailable", !exists);
          btn.title = exists ? "" : "This dataset was not listed by the backend";
        });
        log("Datasets loaded", names.join(", "), "success");
      } else {
        log("Datasets endpoint returned no recognized list", JSON.stringify(data).slice(0, 180), "warning");
      }
    } catch (err) { log("Could not load datasets", err.message, "warning"); }
  }
  $("switch-btn").addEventListener("click", async () => {
    const btn = $("switch-btn");
    btn.disabled = true;
    $("switch-feedback").textContent = "Switching dataset…";
    try {
      const result = await C.request("/api/data-stream/switch", { method: "POST", body: JSON.stringify({ dataset: selectedDataset }) });
      const active = result.dataset || result.current_dataset || selectedDataset;
      $("current-dataset").textContent = active;
      $("current-position").textContent = "0";
      $("switch-feedback").textContent = `Active dataset: ${active}`;
      $("switch-feedback").className = "feedback success-text";
      log("Dataset switched", active, "success");
      await refreshStatus();
    } catch (err) {
      $("switch-feedback").textContent = `Switch failed: ${err.message}`;
      $("switch-feedback").className = "feedback error-text";
      log("Dataset switch failed", err.message, "warning");
    } finally { btn.disabled = false; }
  });
  $("connect-btn").addEventListener("click", connect);
  $("disconnect-btn").addEventListener("click", disconnect);
  $("clear-log").addEventListener("click", () => { logs.length = 0; $("control-log").innerHTML = '<div class="empty-state compact">No activity yet.</div>'; });
  window.addEventListener("beforeunload", () => { if (socket) socket.close(); });
  setSocketStatus(false, "Checking API");
  loadDatasets();
  refreshStatus();
  connect();
  window.setInterval(refreshStatus, 5000);
})();
