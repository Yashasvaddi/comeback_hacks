# CORTEX static frontend (pure HTML, CSS and JavaScript)

No React, Next.js, npm, bundler, or frontend framework is used.

## Pages
- `index.html` — live telemetry dashboard
- `control.html` — dataset switching and browser WebSocket controls
- `assets/` — shared CSS and JavaScript

## Configure the API
Edit `assets/config.js`:
```js
window.CORTEX_CONFIG = {
  API_BASE: "https://godfatherspersonalcomputer.shop",
  WS_PATH: "/ws/data-stream"
};
```

Expected backend routes:
- `GET /api/data-stream/datasets`
- `GET /api/data-stream/status`
- `POST /api/data-stream/switch` with JSON `{"dataset":"dataset_2"}`
- WebSocket `/ws/data-stream`

## Run locally
Because browsers can restrict some cross-origin requests when opening a file directly, serve this folder over HTTP. For example, from this folder:
```bash
python -m http.server 5500
```
Then open `http://localhost:5500`.

## Deploy
Upload the folder contents to any static web server or serve them through your existing frontend web server. No build step is required.

## Important
The API domain must proxy `/api/data-stream/*` to FastAPI and support WebSocket upgrades for `/ws/data-stream`. If frontend and API are on different origins, configure the backend CORS policy for the frontend origin. This UI is a demo for synthetic CSV data, not physical equipment.
